import { getOctokit } from "../github";

export async function analyzeReadme(owner: string, repo: string): Promise<{ sections: string[]; completenessScore: number; hasUsage: boolean; hasDeploy: boolean }> {
  const octokit = getOctokit();
  let content: string | null = null;

  // Try common README filenames
  for (const path of ["README.md", "Readme.md", "readme.md"]) {
    try {
      const res = await octokit.repos.getContent({ owner, repo, path });
      if (!("content" in res.data)) continue;
      const decoded = Buffer.from(res.data.content, "base64").toString("utf-8");
      content = decoded;
      break;
    } catch {
      // continue
    }
  }

  if (!content) {
    return { sections: [], completenessScore: 0, hasUsage: false, hasDeploy: false };
  }

  const sections = [];
  const checks = [
    { key: "Overview", re: /#+\s*(overview|about|introduction)/i },
    { key: "Installation", re: /#+\s*(install|setup)/i },
    { key: "Usage", re: /#+\s*(usage|run|how to)/i },
    { key: "License", re: /#+\s*(license)/i },
    { key: "Contributing", re: /#+\s*(contributing|contribution)/i },
    { key: "Tests", re: /#+\s*(test|testing)/i },
  ];

  for (const c of checks) {
    if (c.re.test(content)) sections.push(c.key);
  }

  const completenessScore = Math.round((sections.length / checks.length) * 100);
  const hasUsage = /```|\$ (npm|pnpm|yarn|python|pip)/i.test(content);
  const hasDeploy = /(deploy|docker|compose|vercel|netlify|render\.com)/i.test(content);

  return { sections, completenessScore, hasUsage, hasDeploy };
}

export default analyzeReadme;