import { getOctokit } from "../github";

export type StructureStats = { hasSrc: boolean; hasTests: boolean; nestingDepth: number };

export async function analyzeStructure(owner: string, repo: string): Promise<StructureStats> {
  const octokit = getOctokit();
  const root = await octokit.repos.getContent({ owner, repo, path: "" });
  const items = Array.isArray(root.data) ? root.data : [];

  const hasSrc = items.some((i: any) => i.type === "dir" && /^src$/i.test(i.name));
  const hasTests = items.some((i: any) => i.type === "dir" && /^(test|tests|__tests__)$/i.test(i.name));

  // Estimate nesting depth by sampling top-level dirs
  let nestingDepth = 1;
  for (const dir of items.filter((i: any) => i.type === "dir").slice(0, 5)) {
    try {
      const res = await octokit.repos.getContent({ owner, repo, path: dir.path });
      const subItems = Array.isArray(res.data) ? res.data : [];
      const subDirs = subItems.filter((i: any) => i.type === "dir");
      nestingDepth = Math.max(nestingDepth, subDirs.length > 0 ? 2 : 1);
    } catch {
      // ignore
    }
  }

  return { hasSrc, hasTests, nestingDepth };
}

export default analyzeStructure;