import Fastify from "fastify";
import cors from "@fastify/cors";
import { z } from "zod";
import { parseRepoUrl, fetchRepoMetadata, fetchCommitStats } from "./github";
import analyzeReadme from "./analyzers/readme";
import analyzeStructure from "./analyzers/structure";
import analyzeCodeQuality from "./analyzers/codeQuality";
import { type AnalysisDetails, type AnalysisResult } from "./types";
import { scoreDimensions, overallScore, category, summarize, roadmap } from "./scoring";

const app = Fastify({ logger: true });
app.register(cors, { origin: true });

const AnalyzeBody = z.object({
  repo_url: z.string().url(),
  run_tests: z.boolean().optional(),
});

app.post("/api/analyze", async (req, reply) => {
  const parsed = AnalyzeBody.safeParse((req as any).body);
  if (!parsed.success) {
    return reply.status(400).send({ error: "Invalid body", issues: parsed.error.issues });
  }

  try {
    const { owner, name } = parseRepoUrl(parsed.data.repo_url);
    const [meta, commits, readme, structure, codeq] = await Promise.all([
      fetchRepoMetadata(owner, name),
      fetchCommitStats(owner, name),
      analyzeReadme(owner, name),
      analyzeStructure(owner, name),
      analyzeCodeQuality(owner, name),
    ]);

    const details: AnalysisDetails = {
      codeQuality: { ...codeq },
      docs: { readmeSections: readme.sections, completenessScore: readme.completenessScore },
      tests: { hasTestsFolder: structure.hasTests, coveragePercent: undefined },
      structure: { hasSrc: structure.hasSrc, hasTests: structure.hasTests, nestingDepth: structure.nestingDepth },
      relevance: { hasUsageExample: readme.hasUsage, hasDeploymentInstructions: readme.hasDeploy },
      repo: {
        hasReadme: meta.hasReadme,
        hasCi: meta.hasCi,
        hasDockerfile: meta.hasDockerfile,
        license: meta.license,
        description: meta.description,
        filesCount: meta.filesCount,
        foldersCount: meta.foldersCount,
      },
      commits,
    };

    const dim = scoreDimensions(details);
    const score = overallScore(dim);
    const cat = category(score);

    const result: AnalysisResult = {
      repository: {
        owner,
        name,
        default_branch: meta.defaultBranch,
        languages: Object.keys(meta.languageBreakdown),
        last_commit_date: commits.lastCommitDate,
      },
      score,
      category: cat,
      summary: summarize(details, score),
      roadmap: roadmap(details),
      details: { dimension_scores: dim, raw_findings: details },
    };

    return reply.send(result);
  } catch (err: any) {
    req.log.error(err);
    return reply.status(500).send({ error: err.message || "Analysis failed" });
  }
});

const port = Number(process.env.PORT || 3001);
app.listen({ port, host: "0.0.0.0" }).then(() => {
  console.log(`Backend listening on http://localhost:${port}`);
});