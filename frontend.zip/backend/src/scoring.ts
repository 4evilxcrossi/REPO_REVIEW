import type { AnalysisDetails, DimensionScores } from "./types";

export function scoreDimensions(details: AnalysisDetails): DimensionScores {
  // Code quality: base on TODOs and complexity; placeholder until ESLint wired
  const cq = clamp(100 - details.codeQuality.todoCount * 2 - (details.codeQuality.avgComplexity ?? 0) * 3, 0, 100);

  // Docs: completeness + presence of README/description/license
  const docsBase = details.repo.hasReadme ? 20 : -10;
  const docsMeta = (details.repo.description ? 5 : 0) + (details.repo.license ? 5 : 0);
  const docs = clamp(details.docs.completenessScore * 0.8 + docsBase + docsMeta, 0, 100);

  // Tests: 0 if no tests folder, else coverage or baseline 40, with CI bonus
  let tests = details.tests.hasTestsFolder ? (details.tests.coveragePercent ?? 40) : 0;
  if (details.repo.hasCi) tests += 10;
  tests = clamp(tests, 0, 100);

  // Commits: based on commits/week and PR usage
  const commitBase = Math.min(100, (details.commits.commitsPerWeek ?? 0) * 10); // 10 commits/week => 100
  const prBonus = (details.commits.prsOpen ?? 0) + (details.commits.prsClosed ?? 0) > 0 ? 10 : 0;
  const contributorBonus = Math.min(details.commits.contributorsCount * 2, 10);
  const commits = clamp(commitBase + prBonus + contributorBonus, 0, 100);

  // Structure: src/tests presence and shallow nesting
  let structure = 50;
  if (details.structure.hasSrc) structure += 20;
  if (details.structure.hasTests) structure += 20;
  if (details.structure.nestingDepth <= 2) structure += 10;
  if (details.repo.filesCount > 0 && details.repo.filesCount <= 40) structure += 5;
  structure = clamp(structure, 0, 100);

  // Relevance: usage/deploy signals + CI/Dockerfile/license flags
  let relevance = 30;
  if (details.relevance.hasUsageExample) relevance += 15;
  if (details.relevance.hasDeploymentInstructions) relevance += 15;
  if (details.repo.hasCi) relevance += 10;
  if (details.repo.hasDockerfile) relevance += 10;
  if (details.repo.license) relevance += 5;
  relevance += details.commits.branchesCount && details.commits.branchesCount > 1 ? 10 : 0;

  return {
    code_quality: Math.round(cq),
    docs: Math.round(docs),
    tests: Math.round(tests),
    commits: Math.round(commits),
    structure: Math.round(structure),
    relevance: Math.round(clamp(relevance, 0, 100)),
  };
}

export function overallScore(d: DimensionScores): number {
  // Weights: CQ 25, Docs 20, Tests 20, Commits 15, Structure 10, Relevance 10
  const score =
    0.25 * d.code_quality +
    0.20 * d.docs +
    0.20 * d.tests +
    0.15 * d.commits +
    0.10 * d.structure +
    0.10 * d.relevance;
  return Math.round(score);
}

export function category(score: number): "Beginner" | "Intermediate" | "Advanced" {
  if (score < 50) return "Beginner";
  if (score < 80) return "Intermediate";
  return "Advanced";
}

export function summarize(details: AnalysisDetails, score: number): string {
  const strengths: string[] = [];
  const weaknesses: string[] = [];

  if (details.structure.hasSrc) strengths.push("clear source structure");
  if (details.tests.hasTestsFolder) strengths.push("tests present");
  if (details.docs.completenessScore >= 60) strengths.push("decent documentation");
  if ((details.commits.commitsPerWeek ?? 0) >= 2) strengths.push("consistent commits");
  if (details.repo.hasCi) strengths.push("CI configured");
  if (details.repo.hasDockerfile) strengths.push("containerization ready");

  if (!details.repo.hasReadme || details.docs.completenessScore < 60) weaknesses.push("documentation needs improvement");
  if (!details.tests.hasTestsFolder) weaknesses.push("no tests");
  if ((details.codeQuality.todoCount ?? 0) > 5) weaknesses.push("too many TODO/FIXME comments");
  if ((details.codeQuality.avgComplexity ?? 0) > 10) weaknesses.push("complex functions");
  if (!details.repo.hasCi) weaknesses.push("no automated CI checks");
  if (!details.repo.license) weaknesses.push("missing license");

  const s = strengths.length ? `Strengths: ${strengths.join(", ")}. ` : "";
  const w = weaknesses.length ? `Areas to improve: ${weaknesses.join(", ")}. ` : "";
  return `${s}${w}Overall score: ${score}/100.`;
}

export function roadmap(details: AnalysisDetails): { step: string; why: string; estimate: "Low" | "Medium" | "High" }[] {
  const items: { step: string; why: string; estimate: "Low" | "Medium" | "High" }[] = [];

  if (!details.tests.hasTestsFolder) {
    items.push({
      step: "Add a tests/ folder with unit tests (e.g., Jest or PyTest)",
      why: "Improves reliability and confidence to refactor",
      estimate: "Medium",
    });
  } else if (!details.tests.coveragePercent) {
    items.push({
      step: "Measure and publish test coverage (nyc/coverage.py) with a badge",
      why: "Signals quality to reviewers and recruiters",
      estimate: "Low",
    });
  }
  if (!details.repo.hasReadme || details.docs.completenessScore < 80) {
    items.push({
      step: "Expand README.md with Overview, Installation, Usage, Tests, Contributing, License",
      why: "Helps recruiters and users understand and run the project",
      estimate: "Low",
    });
  }
  if (!details.repo.license) {
    items.push({
      step: "Add a LICENSE file (MIT/Apache-2.0) and mention it in README",
      why: "Clarifies usage rights and looks professional",
      estimate: "Low",
    });
  }
  if ((details.codeQuality.todoCount ?? 0) > 0) {
    items.push({
      step: "Resolve or track TODO/FIXME with issues",
      why: "Reduces technical debt and clarifies backlog",
      estimate: "Low",
    });
  }
  if (!details.repo.hasCi) {
    items.push({
      step: "Add CI via GitHub Actions to run lint and tests on push",
      why: "Automates quality checks and shows best practices",
      estimate: "Low",
    });
  }
  if (details.commits.branchesCount && details.commits.branchesCount <= 1) {
    items.push({
      step: "Adopt branch + PR workflow with reviews",
      why: "Improves code quality and signals collaboration",
      estimate: "Low",
    });
  }
  if (!details.repo.hasDockerfile && details.relevance.hasDeploymentInstructions) {
    items.push({
      step: "Add a Dockerfile for reproducible dev/test",
      why: "Makes running the project easier for recruiters and CI",
      estimate: "Medium",
    });
  }
  if ((details.commits.commitsPerWeek ?? 0) < 1) {
    items.push({
      step: "Increase commit cadence to at least weekly with meaningful messages",
      why: "Shows active development and maintainability",
      estimate: "Low",
    });
  }
  return items.slice(0, 6);
}

function clamp(v: number, min: number, max: number) {
  return Math.max(min, Math.min(max, v));
}