export type RepoInput = {
  repoUrl: string;
  runTests?: boolean;
};

export type RepoMetadata = {
  owner: string;
  name: string;
  defaultBranch: string;
  description?: string | null;
  languageBreakdown: Record<string, number>;
  license?: string | null;
  hasReadme: boolean;
  hasCi: boolean;
  hasDockerfile: boolean;
  filesCount: number;
  foldersCount: number;
};

export type RepoSignals = {
  hasReadme: boolean;
  hasCi: boolean;
  hasDockerfile: boolean;
  license?: string | null;
  description?: string | null;
  filesCount: number;
  foldersCount: number;
};

export type CommitStats = {
  totalCommits: number;
  firstCommitDate?: string;
  lastCommitDate?: string;
  commitsPerWeek?: number;
  contributorsCount: number;
  branchesCount?: number;
  prsOpen?: number;
  prsClosed?: number;
};

export type AnalysisDetails = {
  codeQuality: {
    lintErrors: number;
    lintWarnings: number;
    todoCount: number;
    avgComplexity?: number;
  };
  docs: {
    readmeSections: string[];
    completenessScore: number;
  };
  tests: {
    hasTestsFolder: boolean;
    coveragePercent?: number;
  };
  structure: {
    hasSrc: boolean;
    hasTests: boolean;
    nestingDepth: number;
  };
  relevance: {
    hasUsageExample: boolean;
    hasDeploymentInstructions: boolean;
  };
  repo: RepoSignals;
  commits: CommitStats;
};

export type DimensionScores = {
  code_quality: number;
  docs: number;
  tests: number;
  commits: number;
  structure: number;
  relevance: number;
};

export type AnalysisResult = {
  repository: {
    owner: string;
    name: string;
    default_branch: string;
    languages: string[];
    last_commit_date?: string;
  };
  score: number;
  category: "Beginner" | "Intermediate" | "Advanced";
  summary: string;
  roadmap: { step: string; why: string; estimate: "Low" | "Medium" | "High" }[];
  details: {
    dimension_scores: DimensionScores;
    raw_findings: AnalysisDetails;
  };
};