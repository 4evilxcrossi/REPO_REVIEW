import { useMemo, useState, useEffect } from "react";

type Result = {
  score: number;
  category: string;
  summary: string;
  roadmap: { step: string; why: string; estimate: string }[];
  repository: {
    owner: string;
    name: string;
    default_branch: string;
    languages: string[];
    last_commit_date?: string;
  };
  details: {
    dimension_scores: Record<string, number>;
    raw_findings?: {
      repo?: {
        hasReadme: boolean;
        hasCi: boolean;
        hasDockerfile: boolean;
        license?: string | null;
        description?: string | null;
        filesCount: number;
        foldersCount: number;
      };
    };
  };
};

export default function Home() {
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<Result | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [animatedScore, setAnimatedScore] = useState(0);

  const backendUrl = useMemo(
    () => process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:3001/api/analyze",
    [],
  );

  // Animate score when result changes
  useEffect(() => {
    if (result) {
      setAnimatedScore(0);
      const duration = 1500;
      const steps = 60;
      const increment = result.score / steps;
      const stepTime = duration / steps;
      let current = 0;
      const timer = setInterval(() => {
        current += increment;
        if (current >= result.score) {
          setAnimatedScore(result.score);
          clearInterval(timer);
        } else {
          setAnimatedScore(Math.floor(current));
        }
      }, stepTime);
      return () => clearInterval(timer);
    }
  }, [result]);

  const analyze = async () => {
    if (!url) return;
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const res = await fetch(backendUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ repo_url: url.trim() }),
      });
      if (!res.ok) throw new Error((await res.text()) || "Request failed");
      const data = await res.json();
      setResult(data);
    } catch (e: any) {
      setError(e?.message || "Failed to analyze");
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (value?: string) => {
    if (!value) return "Unknown";
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? "Unknown" : date.toLocaleDateString();
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return { bg: "linear-gradient(135deg, #10b981 0%, #059669 100%)", text: "#fff" };
    if (score >= 60) return { bg: "linear-gradient(135deg, #f59e0b 0%, #d97706 100%)", text: "#fff" };
    return { bg: "linear-gradient(135deg, #ef4444 0%, #dc2626 100%)", text: "#fff" };
  };


  return (
    <>
      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        
        * {
          box-sizing: border-box;
        }
        
        body {
          margin: 0;
          padding: 0;
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
          background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #334155 100%);
          min-height: 100vh;
          background-attachment: fixed;
        }
        
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        @keyframes pulse {
          0%, 100% {
            opacity: 1;
          }
          50% {
            opacity: 0.5;
          }
        }
        
        @keyframes shimmer {
          0% {
            background-position: -1000px 0;
          }
          100% {
            background-position: 1000px 0;
          }
        }
        
        .fade-in {
          animation: fadeIn 0.6s ease-out;
        }
        
        .loading-skeleton {
          background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
          background-size: 1000px 100%;
          animation: shimmer 2s infinite;
          border-radius: 8px;
        }
      `}</style>
      
      <main
        style={{
          maxWidth: 1200,
          margin: "0 auto",
          padding: "40px 20px",
          minHeight: "100vh",
        }}
      >
        {/* Header */}
        <header
          className="fade-in"
          style={{
            textAlign: "center",
            marginBottom: "48px",
            color: "#fff",
          }}
        >
          <div
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "8px",
              padding: "8px 16px",
              background: "rgba(255, 255, 255, 0.2)",
              backdropFilter: "blur(10px)",
              borderRadius: "50px",
              fontSize: "14px",
              fontWeight: 600,
              marginBottom: "16px",
              border: "1px solid rgba(255, 255, 255, 0.3)",
            }}
          >
            IRIS Insight
          </div>
          <h1
            style={{
              fontSize: "clamp(32px, 5vw, 56px)",
              fontWeight: 800,
              margin: "0 0 16px 0",
              background: "linear-gradient(135deg, #fff 0%, #cbd5e1 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}
          >
            Repository Analyzer
          </h1>
          <p
            style={{
              fontSize: "18px",
              margin: "0 auto",
              maxWidth: "600px",
              opacity: 0.95,
              lineHeight: 1.6,
            }}
          >
            Get instant insights into any GitHub repository. Analyze code quality, documentation, structure, and get actionable recommendations.
          </p>
        </header>

        {/* Input Section */}
        <section className="fade-in" style={{ marginBottom: "32px" }}>
          <div
            style={{
              background: "rgba(255, 255, 255, 0.95)",
              backdropFilter: "blur(20px)",
              borderRadius: "24px",
              padding: "32px",
              boxShadow: "0 20px 60px rgba(0, 0, 0, 0.3)",
              border: "1px solid rgba(255, 255, 255, 0.5)",
            }}
          >
            <label
              style={{
                display: "block",
                fontWeight: 600,
                fontSize: "16px",
                marginBottom: "12px",
                color: "#1e293b",
              }}
            >
              Repository URL
            </label>
            <div style={{ display: "flex", gap: "12px", flexWrap: "wrap" }}>
              <input
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && !loading && url && analyze()}
                placeholder="https://github.com/owner/repo"
                disabled={loading}
                style={{
                  flex: 1,
                  minWidth: "280px",
                  padding: "16px 20px",
                  borderRadius: "12px",
                  border: "2px solid #e2e8f0",
                  fontSize: "16px",
                  transition: "all 0.3s ease",
                  outline: "none",
                }}
                onFocus={(e) => {
                  e.target.style.borderColor = "#3b82f6";
                  e.target.style.boxShadow = "0 0 0 3px rgba(59, 130, 246, 0.1)";
                }}
                onBlur={(e) => {
                  e.target.style.borderColor = "#e2e8f0";
                  e.target.style.boxShadow = "none";
                }}
              />
              <button
                onClick={analyze}
                disabled={loading || !url}
                style={{
                  padding: "16px 32px",
                  background: loading || !url
                    ? "#475569"
                    : "linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)",
                  color: "#fff",
                  border: "none",
                  borderRadius: "12px",
                  cursor: loading || !url ? "not-allowed" : "pointer",
                  fontWeight: 600,
                  fontSize: "16px",
                  transition: "all 0.3s ease",
                  boxShadow: loading || !url
                    ? "none"
                    : "0 4px 15px rgba(59, 130, 246, 0.4)",
                  transform: loading || !url ? "none" : "translateY(0)",
                }}
                onMouseEnter={(e) => {
                  if (!loading && url) {
                    e.currentTarget.style.transform = "translateY(-2px)";
                    e.currentTarget.style.boxShadow = "0 6px 20px rgba(59, 130, 246, 0.5)";
                  }
                }}
                onMouseLeave={(e) => {
                  if (!loading && url) {
                    e.currentTarget.style.transform = "translateY(0)";
                    e.currentTarget.style.boxShadow = "0 4px 15px rgba(59, 130, 246, 0.4)";
                  }
                }}
              >
                {loading ? "Analyzing..." : "Analyze Repository"}
              </button>
            </div>
            {loading && (
              <div
                style={{
                  marginTop: "20px",
                  padding: "16px",
                  background: "linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%)",
                  backgroundSize: "200% 100%",
                  borderRadius: "12px",
                  animation: "shimmer 2s infinite",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: "12px", color: "#64748b" }}>
                  <span>Analyzing repository structure, code quality, documentation, and more...</span>
                </div>
              </div>
            )}
          </div>

          {error && (
            <div
              className="fade-in"
              style={{
                marginTop: "16px",
                padding: "20px",
                background: "linear-gradient(135deg, #fee2e2 0%, #fecaca 100%)",
                borderRadius: "16px",
                border: "2px solid #fca5a5",
                color: "#991b1b",
                fontWeight: 500,
                display: "flex",
                alignItems: "center",
                gap: "12px",
              }}
            >
              <span>{error}</span>
            </div>
          )}
        </section>

        {/* Results */}
        {result && (
          <section className="fade-in" style={{ display: "grid", gap: "24px" }}>
            {/* Repository Header */}
            <div
              style={{
                background: "rgba(255, 255, 255, 0.95)",
                backdropFilter: "blur(20px)",
                borderRadius: "24px",
                padding: "32px",
                boxShadow: "0 20px 60px rgba(0, 0, 0, 0.3)",
                border: "1px solid rgba(255, 255, 255, 0.5)",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "20px" }}>
                <div>
                  <h2
                    style={{
                      fontSize: "28px",
                      fontWeight: 700,
                      margin: 0,
                      color: "#1e293b",
                    }}
                  >
                    {result.repository.owner}/{result.repository.name}
                  </h2>
                  {result.details.raw_findings?.repo?.description && (
                    <p style={{ margin: "8px 0 0 0", color: "#64748b", fontSize: "16px" }}>
                      {result.details.raw_findings.repo.description}
                    </p>
                  )}
                </div>
              </div>

              <div style={{ display: "flex", gap: "12px", flexWrap: "wrap", marginBottom: "20px" }}>
                <span
                  style={{
                    padding: "8px 16px",
                    background: "#f1f5f9",
                    borderRadius: "20px",
                    fontSize: "14px",
                    fontWeight: 500,
                    color: "#475569",
                  }}
                >
                  Branch: {result.repository.default_branch}
                </span>
                <span
                  style={{
                    padding: "8px 16px",
                    background: "linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)",
                    borderRadius: "20px",
                    fontSize: "14px",
                    fontWeight: 500,
                    color: "#fff",
                  }}
                >
                  Languages: {result.repository.languages.join(" · ") || "Unknown"}
                </span>
                <span
                  style={{
                    padding: "8px 16px",
                    background: "#f1f5f9",
                    borderRadius: "20px",
                    fontSize: "14px",
                    fontWeight: 500,
                    color: "#475569",
                  }}
                >
                  Last Commit: {formatDate(result.repository.last_commit_date)}
                </span>
              </div>

              {result.details.raw_findings?.repo && (
                <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
                  <span
                    style={{
                      padding: "6px 14px",
                      background: result.details.raw_findings.repo.hasCi
                        ? "linear-gradient(135deg, #10b981 0%, #059669 100%)"
                        : "#e2e8f0",
                      borderRadius: "20px",
                      fontSize: "13px",
                      fontWeight: 500,
                      color: result.details.raw_findings.repo.hasCi ? "#fff" : "#64748b",
                    }}
                  >
                    {result.details.raw_findings.repo.hasCi ? "CI/CD" : "No CI"}
                  </span>
                  <span
                    style={{
                      padding: "6px 14px",
                      background: result.details.raw_findings.repo.hasDockerfile
                        ? "linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%)"
                        : "#e2e8f0",
                      borderRadius: "20px",
                      fontSize: "13px",
                      fontWeight: 500,
                      color: result.details.raw_findings.repo.hasDockerfile ? "#fff" : "#64748b",
                    }}
                  >
                    {result.details.raw_findings.repo.hasDockerfile ? "Docker" : "No Docker"}
                  </span>
                  <span
                    style={{
                      padding: "6px 14px",
                      background: result.details.raw_findings.repo.hasReadme
                        ? "linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)"
                        : "#e2e8f0",
                      borderRadius: "20px",
                      fontSize: "13px",
                      fontWeight: 500,
                      color: result.details.raw_findings.repo.hasReadme ? "#fff" : "#64748b",
                    }}
                  >
                    {result.details.raw_findings.repo.hasReadme ? "README" : "No README"}
                  </span>
                  {result.details.raw_findings.repo.license && (
                    <span
                      style={{
                        padding: "6px 14px",
                        background: "linear-gradient(135deg, #1e293b 0%, #0f172a 100%)",
                        borderRadius: "20px",
                        fontSize: "13px",
                        fontWeight: 500,
                        color: "#fff",
                      }}
                    >
                      License: {result.details.raw_findings.repo.license}
                    </span>
                  )}
                </div>
              )}

              <div
                style={{
                  marginTop: "20px",
                  padding: "20px",
                  background: "linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%)",
                  borderRadius: "16px",
                  color: "#475569",
                  lineHeight: 1.7,
                  fontSize: "16px",
                }}
              >
                {result.summary}
              </div>
            </div>

            {/* Score Cards */}
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
                gap: "20px",
              }}
            >
              {/* Overall Score */}
              <div
                style={{
                  background: "rgba(255, 255, 255, 0.95)",
                  backdropFilter: "blur(20px)",
                  borderRadius: "24px",
                  padding: "32px",
                  boxShadow: "0 20px 60px rgba(0, 0, 0, 0.3)",
                  border: "1px solid rgba(255, 255, 255, 0.5)",
                  textAlign: "center",
                  position: "relative",
                  overflow: "hidden",
                }}
              >
                <div
                  style={{
                    position: "absolute",
                    top: 0,
                    left: 0,
                    right: 0,
                    height: "6px",
                    background: getScoreColor(result.score).bg,
                  }}
                />
                <div
                  style={{
                    fontSize: "14px",
                    fontWeight: 600,
                    textTransform: "uppercase",
                    letterSpacing: "1px",
                    color: "#64748b",
                    marginBottom: "8px",
                  }}
                >
                  {result.category}
                </div>
                <div
                  style={{
                    fontSize: "64px",
                    fontWeight: 800,
                    background: getScoreColor(result.score).bg,
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                    backgroundClip: "text",
                    marginBottom: "8px",
                  }}
                >
                  {animatedScore}/100
                </div>
                <div style={{ color: "#64748b", fontSize: "14px" }}>
                  Overall Quality Score
                </div>
              </div>

              {/* Dimension Scores */}
              <div
                style={{
                  background: "rgba(255, 255, 255, 0.95)",
                  backdropFilter: "blur(20px)",
                  borderRadius: "24px",
                  padding: "32px",
                  boxShadow: "0 20px 60px rgba(0, 0, 0, 0.3)",
                  border: "1px solid rgba(255, 255, 255, 0.5)",
                }}
              >
                <h3
                  style={{
                    fontSize: "20px",
                    fontWeight: 700,
                    margin: "0 0 20px 0",
                    color: "#1e293b",
                  }}
                >
                  Dimension Scores
                </h3>
                <div style={{ display: "grid", gap: "16px" }}>
                  {Object.entries(result.details.dimension_scores).map(([key, value]) => {
                      const percentage = value;
                      const color = percentage >= 80 ? "#10b981" : percentage >= 60 ? "#f59e0b" : "#ef4444";
                      return (
                        <div key={key}>
                          <div
                            style={{
                              display: "flex",
                              justifyContent: "space-between",
                              marginBottom: "8px",
                              fontSize: "14px",
                              fontWeight: 600,
                              color: "#1e293b",
                            }}
                          >
                            <span style={{ textTransform: "capitalize" }}>
                              {key.replace(/_/g, " ")}
                            </span>
                            <span style={{ color }}>{value}/100</span>
                          </div>
                          <div
                            style={{
                              height: "8px",
                              background: "#e2e8f0",
                              borderRadius: "4px",
                              overflow: "hidden",
                            }}
                          >
                            <div
                              style={{
                                height: "100%",
                                width: `${percentage}%`,
                                background: `linear-gradient(90deg, ${color} 0%, ${color}dd 100%)`,
                                borderRadius: "4px",
                                transition: "width 1s ease-out",
                              }}
                            />
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>

            {/* Roadmap */}
            <div
              style={{
                background: "rgba(255, 255, 255, 0.95)",
                backdropFilter: "blur(20px)",
                borderRadius: "24px",
                padding: "32px",
                boxShadow: "0 20px 60px rgba(0, 0, 0, 0.3)",
                border: "1px solid rgba(255, 255, 255, 0.5)",
              }}
            >
              <h3
                style={{
                  fontSize: "24px",
                  fontWeight: 700,
                  margin: "0 0 24px 0",
                  color: "#1e293b",
                  display: "flex",
                  alignItems: "center",
                  gap: "12px",
                }}
              >
                Improvement Roadmap
              </h3>
              <div style={{ display: "grid", gap: "16px" }}>
                {result.roadmap.map((item, i) => (
                  <div
                    key={i}
                    style={{
                      padding: "20px",
                      background: "linear-gradient(135deg, #f8fafc 0%, #ffffff 100%)",
                      borderRadius: "16px",
                      border: "2px solid #e2e8f0",
                      transition: "all 0.3s ease",
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.borderColor = "#3b82f6";
                      e.currentTarget.style.transform = "translateX(4px)";
                      e.currentTarget.style.boxShadow = "0 4px 12px rgba(59, 130, 246, 0.15)";
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.borderColor = "#e2e8f0";
                      e.currentTarget.style.transform = "translateX(0)";
                      e.currentTarget.style.boxShadow = "none";
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "flex-start",
                        gap: "16px",
                        marginBottom: "12px",
                        flexWrap: "wrap",
                      }}
                    >
                      <div style={{ flex: 1, minWidth: "200px" }}>
                        <div
                          style={{
                            fontSize: "18px",
                            fontWeight: 700,
                            color: "#1e293b",
                            marginBottom: "8px",
                          }}
                        >
                          {i + 1}. {item.step}
                        </div>
                        <div style={{ color: "#64748b", lineHeight: 1.6, fontSize: "15px" }}>
                          {item.why}
                        </div>
                      </div>
                      <span
                        style={{
                          padding: "6px 14px",
                          background:
                            item.estimate === "Low"
                              ? "linear-gradient(135deg, #10b981 0%, #059669 100%)"
                              : item.estimate === "Medium"
                              ? "linear-gradient(135deg, #f59e0b 0%, #d97706 100%)"
                              : "linear-gradient(135deg, #ef4444 0%, #dc2626 100%)",
                          borderRadius: "20px",
                          fontSize: "13px",
                          fontWeight: 600,
                          color: "#fff",
                          whiteSpace: "nowrap",
                        }}
                      >
                        {item.estimate} Effort
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}
      </main>
    </>
  );
}
