import { getOctokit } from "../github";

export type CodeQualityStats = {
  lintErrors: number;
  lintWarnings: number;
  todoCount: number;
  avgComplexity?: number;
};

export async function analyzeCodeQuality(owner: string, repo: string): Promise<CodeQualityStats> {
  const octokit = getOctokit();

  // Lightweight heuristic: scan text files for TODO/FIXME and approximate complexity with "if/for/while/case" density
  // For hackathon MVP, we avoid cloning; we sample up to N files from the repo root and src/.
  const pathsToScan = new Set<string>();
  const addDir = async (path: string) => {
    try {
      const res = await octokit.repos.getContent({ owner, repo, path });
      if (Array.isArray(res.data)) {
        res.data.forEach((i: any) => {
          if (i.type === "file") pathsToScan.add(i.path);
          if (i.type === "dir" && /^(src|lib|app)$/i.test(i.name)) pathsToScan.add(i.path);
        });
      }
    } catch {
      // ignore
    }
  };
  await addDir("");
  await addDir("src");

  let todoCount = 0;
  let complexityTokens = 0;
  let scannedFiles = 0;

  for (const p of Array.from(pathsToScan).slice(0, 50)) {
    try {
      const file = await octokit.repos.getContent({ owner, repo, path: p });
      if (!("content" in file.data)) continue;
      const text = Buffer.from(file.data.content, "base64").toString("utf-8");
      if (!isTextFile(p)) continue;
      scannedFiles++;

      const todos = (text.match(/(TODO|FIXME|HACK|XXX)/g) || []).length;
      todoCount += todos;

      const tokens = (text.match(/\b(if|for|while|case|catch|elif|switch)\b/g) || []).length;
      complexityTokens += tokens;
    } catch {
      // ignore
    }
  }

  const avgComplexity = scannedFiles ? Number((complexityTokens / scannedFiles).toFixed(2)) : undefined;

  // Placeholder for lint integration: if you decide to clone locally, run ESLint and parse results.
  const lintErrors = 0;
  const lintWarnings = 0;

  return { lintErrors, lintWarnings, todoCount, avgComplexity };
}

function isTextFile(path: string) {
  return /\.(ts|js|tsx|jsx|py|java|go|rs|md|json|yml|yaml|sh|c|cpp)$/i.test(path);
}

export default analyzeCodeQuality;