import "dotenv/config";
import { Octokit } from "@octokit/rest";
import type { RepoMetadata, CommitStats } from "./types";

export function parseRepoUrl(url: string): { owner: string; name: string } {
  // Supports https://github.com/<owner>/<repo>[/...]
  const m = url.match(/^https?:\/\/github\.com\/([^/]+)\/([^/]+)(?:$|\/)/i);
  if (!m) throw new Error("Invalid GitHub repository URL");
  return { owner: m[1], name: m[2].replace(/\.git$/, "") };
}

export function getOctokit() {
  // Optional: set GITHUB_TOKEN for higher rate limits
  const token = process.env.GITHUB_TOKEN;
  return new Octokit(token ? { auth: token } : {});
}

export async function fetchRepoMetadata(owner: string, name: string): Promise<RepoMetadata> {
  const octokit = getOctokit();

  const [repo, languages, contentsRoot, workflows, dockerfile] = await Promise.all([
    octokit.repos.get({ owner, repo: name }),
    octokit.repos.listLanguages({ owner, repo: name }),
    octokit.repos.getContent({ owner, repo: name, path: "" }),
    octokit.repos.getContent({ owner, repo: name, path: ".github/workflows" }).catch(() => ({ data: [] as any[] })),
    octokit.repos.getContent({ owner, repo: name, path: "Dockerfile" }).catch(() => ({ data: null as any })),
  ]);

  const defaultBranch = repo.data.default_branch;
  const description = repo.data.description ?? null;
  const license = repo.data.license?.spdx_id ?? null;
  const languageBreakdown = languages.data as Record<string, number>;

  const rootItems = Array.isArray(contentsRoot.data) ? contentsRoot.data : [];
  const filesCount = rootItems.filter((i: any) => i.type === "file").length;
  const foldersCount = rootItems.filter((i: any) => i.type === "dir").length;

  const hasReadme = rootItems.some((i: any) => /^readme\.md$/i.test(i.name));
  const hasCi = Array.isArray(workflows.data) && workflows.data.length > 0;
  const hasDockerfile = !!(dockerfile as any).data;

  return {
    owner,
    name,
    defaultBranch,
    description,
    languageBreakdown,
    license,
    hasReadme,
    hasCi,
    hasDockerfile,
    filesCount,
    foldersCount,
  };
}

export async function fetchCommitStats(owner: string, name: string): Promise<CommitStats> {
  const octokit = getOctokit();
  // Basic stats: contributors, commits, PRs
  const contributors = await octokit.repos.listContributors({ owner, repo: name, per_page: 100 });
  const contributorsCount = contributors.data.length;

  // Commits (last 90 days)
  const since = new Date(Date.now() - 90 * 24 * 3600 * 1000).toISOString();
  const commits = await octokit.repos.listCommits({ owner, repo: name, since, per_page: 100 });
  const totalCommits = commits.data.length;

  const lastCommitDate = commits.data[0]?.commit.author?.date;
  const firstCommitDate = commits.data[commits.data.length - 1]?.commit.author?.date;

  const prsOpen = (await octokit.pulls.list({ owner, repo: name, state: "open", per_page: 100 })).data.length;
  const prsClosed = (await octokit.pulls.list({ owner, repo: name, state: "closed", per_page: 100 })).data.length;

  // Branches
  const branchesCount = (await octokit.repos.listBranches({ owner, repo: name, per_page: 100 })).data.length;

  // Simple commits/week estimate
  const weeks = 12; // approx for 90 days
  const commitsPerWeek = Number((totalCommits / weeks).toFixed(2));

  return {
    totalCommits,
    firstCommitDate,
    lastCommitDate,
    commitsPerWeek,
    contributorsCount,
    branchesCount,
    prsOpen,
    prsClosed,
  };
}